
$(function () {
    $('#world-map').vectorMap({ map: 'world_mill' });
});